var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}
function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
function inicializa(){
window.cookieconsent.initialise({
    "palette": {
    "popup": {
    "background": "#252e39"
    },
    "button": {
    "background": "#14a7d0"
    }
    },
    "theme": "classic",
    "position": "bottom-right",
    "content": {
    "message": "Esta página web utiliza cookies para mejorar la experiencia del usuario en nuestro sitio web",
    "dismiss": "Acepto",
    "link": "Más información"
    }
    });
}