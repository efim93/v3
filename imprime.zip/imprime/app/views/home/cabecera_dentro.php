<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>Fotocopias baratas</title>
        <meta name="description" content="Somos un equipo profesional, con más de 25 años de experiencia en el sector. Damos la mejor calidad al precio más barato. 0,07 en color y 0,02 € en b/n. Desde la primera copia">
        <meta name="keywords" content="Copistería online barata, reprografía online barata, fotocopias baratas online a domicilio, imprenta online barata, fotocopias online low cost, imprenta digital low cost online, rapidez, autopublicaciones, autoedición de libros"/>
        <!-- Compatible con todos navegadores -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <!-- mi javascript -->
        <script src="../../public/js/js_formulario.js"></script>
        <!-- fontAwesone -->
        <link rel="stylesheet" href="../../public/fontawesome-free-5.11.2-web/css/all.css">
        <!-- lightbox-->
        <link rel="stylesheet" href="../../public/css/lightbox.css">
        <!-- Google fonts -->
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Indie+Flower&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Slabo+27px&display=swap" rel="stylesheet">
        <!-- WOW -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js" />
        <!-- mi Hoja de estilos -->
        <link rel="stylesheet" type="text/css" href="../../public/css/css.css">
</head>
<header class="pa">
        <ul class="vmenu izquierda">
            <li><a href="../" class="logo">ImprimirBARATO</a></li>
            <li><a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook fa-2x" ></i></a></li>
            <li><a href="https://twitter.com/?lang=es" target="_blank"><i class="fab fa-twitter fa-2x"></i></a></li>
            <li><a href="https://web.whatsapp.com/" target="_blank"><i class="fab fa-whatsapp fa-2x text-success"></i></a></li>
        </ul>
   <!--      <h1 class="ht">Te lo llevamos a donde quieras</h1>
        <h3 class="ht">Servicio de mensajería llega a todos los lugares</h3> -->
</header>