<?php 
include_once('conf.php');
include_once('cabecera_dentro.php');
include_once('../app/models/Pedido.php');
session_start();
$_SESSION['fichero']=$_FILES['fichero']['name'];
$_SESSION['paginas']=$_POST['paginas'];
$_SESSION['formato']=$_POST['formato'];
$_SESSION['tinta']=$_POST['tinta'];
$_SESSION['caras']=$_POST['caras'];
$_SESSION['tipoEnc']=$_POST['tipoEnc'];
$_SESSION['metodoEnvio']=$_POST['metodoEnvio'];
$p=new Pedido();
$p->fijarDatos($_POST,$_FILES['fichero']['name']);

$paginas=$p->getNrCopias();
$formato=$p->getFormato();
$color=$p->getTinta();
$caras=$p->getCaras();
$tipo=$p->getTipoEncuadernacion();
$metodo=$p->getMetodoEnvio();
$nombreCliente=$p->getNombreCliente();
$dirrecion=$p->getDirrecionCliente();
$telefono=$p->getTelefonoCliente();
$codigoPostal=$p->getCodigoPostal();
$fichero=$p->getFichero();
	/* guardo el fichero */
$fichero_subido = 'ficheros/'. basename($fichero);
/* nombre fichero*/
$nombre=basename($fichero);

$a=0;
$m='';
$n='';
if (($_FILES["fichero"]["type"] == "application/pdf")&&($_FILES["fichero"]["size"] < 10000000000)) {
		move_uploaded_file($_FILES["fichero"]["tmp_name"], $fichero_subido); 
} else{
	$n="¡Tu Fichero no coresponde al formato pdf!".'<br><i>El fichero no se va imprimir !!!</i>';

	}
@$a=$p->numeroPaginasPdf($fichero_subido);
if($n==''){
	if($paginas!=$a){
			$p->setNrCopias($a);
			$m='¡Ojo tu archivo Pdf tiene mas paginas o menos de lo que piensaste!';
	}
}
$d=$p->__toString();
$e=explode(',',$d);
$datos='';
	for($i=0;$i<count($e); $i++){ 
		if($i==0){
			$datos.=$e[$i];
		}else{
		$datos.='|'.$e[$i];
		}
	}
$n!=''?$datos.='|'.$n:$datos;
$costeTotal=$p->getCosteTotal();
$datos.='|costeTotal:'.$costeTotal.'€';



 ?>
 <body  class="pa">
		<h2>Revisa tus datos del Pedido</h2>
<main>
	<section>
	<div class="centrado amarillo pad-all">
		<h3>Tus Datos introducidos son:</h3>
		<br />
		<div class="pad-d pad-all">
		<label class="rojoOscuro"><?=$n ?><br /><?=$m ?></label>
		<br />
		<label><?=LBL_NOMBRE_ARCHIVO ?></label>
		<br /> 
		<label class="blanco"><?=$nombre ?></label>
		<br />
		<label><?=LBL_NR_PAGINAS ?></label>
		<label class="blanco"><?=$a ?></label>
		<br />
		<label><?=LBL_NR_PAGINAS_CONTADAS ?></label>
		<label class="blanco"><?=$paginas ?></label>
		<br />
		<label><?=LBL_FORMATO ?></label>
		<label class="blanco"><?=$formato ?></label>
		<br />
		<label><?=LBL_TIPO_COLOR ?></label>
		<label class="blanco"><?=$color ?></label>
		<br />
		<label><?=LBL_CARAS ?></label>
		<label class="blanco"><?=$caras ?></label>
		<br />
		<label><?=LBL_TIPO_ENC ?></label>
		<label class="blanco"><?=$tipo ?></label>
		<br />
		<label><?=LBL_METODO ?></label>
		<label class="blanco"><?=$metodo ?></label>
		<br />
	<?php if($metodo=='envio'){ ?>
		<label><?=LBL_D_ENVIO?></label>
		<label class="blanco"><?=$nombreCliente.' , ' ?></label>
		<label class="blanco"><?=$dirrecion.' , '?></label>
		<label class="blanco"><?=$codigoPostal.' , ' ?></label>
		<label class="blanco"><?=$telefono ?></label>
	<?php } ?>
		<hr />
		<h3><?=LBL_PRECIOTOTAL.' '.$costeTotal .' €' ?></h3>
		<a href="crearPedido" class="butonazul">Volver atras</a>
		<form action="enviaCorreo" method="POST" class="flIzq">
			<input type="hidden" name="datos" value="<?=$datos ?>" />
		<input type="submit" name="enviaCorreo" class="butonrojo" value="Enviar Pedido">
		</form>
		</div>
	</div>
	</section>
</main>
</body>
<?php include_once('pie_dentro.php'); ?>