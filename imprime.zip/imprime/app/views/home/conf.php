<?php 
 	define('LBL_FORMATO' , 'Formato de hoja*: ');
 	define('LBL_A4', 'A4');
 	define('LBL_A3','A3');
 	define('LBL_CARAS', 'Impressió*: ');
 	define('LBL_SEXO','Sexo: ');
 	define('LBL_CARA_UNICA','A una cara (Cara externa)');
 	define('LBL_DOBLE_CARA','A doble cara (Cara externa + Cara interna)');
 	define('LBL_TIPO_COLOR','Tipo de tinta*: ');
 	define('LBL_COLOR_NEGRO','Negro');
 	define('LBL_COLOR_COLOR','Color');
 	define('LBL_NR_COPIAS','Numero de Copias*: ');
 	define('LBL_NR_PAGINAS','Numero de Paginas*: ');
 	define('LBL_DOCUMENTO','Documento PDF*: ');
 	define('LBL_TIPO_ENC','Tipo de Encuadernacion*:');
 	define('LBL_NINGUNO','Ninguna');
 	define('LBL_LIBRO','Libro');
 	define('LBL_ESPIRAL','Espiral');
 	define('LBL_METODO', 'Metodo de envío*: ');
 	define('LBL_ENVIO','Envio a domicilio');
 	define('LBL_PUNTO','Recogida en el Punto de distribución');
 	define('LBL_PRECIOTOTAL','Precio Total: ');
 	define('LBL_NOMBRE_ARCHIVO','Nombre del Documento: ');
 	define('LBL_NR_PAGINAS_CONTADAS','Numero de Paginas introducidos: ');
 	define('LBL_DEJA_CORREO','Dejanos tu correo: ');
 	define('LBL_D_ENVIO','Datos del Envio:');

 ?>