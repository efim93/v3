<?php 
include_once('conf.php'); 
include_once('cabecera_dentro.php');
?>
<body class="pa">
	<main>
		<section>
			<h3 class="ht" >Presupuesto imprimir</h3>
			<div class="centrado">
				<div>
					<label><?=LBL_NR_PAGINAS ?></label>
					<input type="number" name="paginas" id="paginas" class="numero" min="0" value="0" />
					<br />
					<div class="formatos">
					<label><?=LBL_FORMATO ?></label>
					<input type="radio" name="formato" value="A4" checked="checked" /><label><?=LBL_A4?></label>
					<input type="radio" name="formato" value="A3" /><label><?=LBL_A3?></label>
					<br /><br />
					</div>
					<label><?=LBL_TIPO_COLOR ?></label>
					<select name="tinta" id="tinta">
						<option value="N" ><?=LBL_COLOR_NEGRO ?></option>
						<option value="C" ><?=LBL_COLOR_COLOR ?></option>
					</select>
					<br /><br />
					<label><?=LBL_CARAS ?></label>
					<br>
					<div class="pad-d">
						<input type="radio" name="caras" value="1" checked="checked" required="required" /><label><?=LBL_CARA_UNICA ?></label>
						<br>
						<input type="radio" name="caras" value="2" required="required" /><label><?=LBL_DOBLE_CARA ?></label>
					</div>
					<br />
					<label><?=LBL_TIPO_ENC ?></label>
					<select name="tipoEnc" id="tipoEnc">
						<option value='ninguna' ><?=LBL_NINGUNO ?></option>
						<option value='libro' ><?=LBL_LIBRO ?></option>
						<option value='espiral' ><?=LBL_ESPIRAL?></option>
					</select>
					<br />
					<button id="presupuesto" class="butonrojo" onclick="validacion()" />Ver Presupuesto</button>
					<a href="crearPedido" class="butonazul">Crea tu Pedido sin Registro</a>
				<div id="contenido"></div>
				</div>
		</section>
	</main>
</body>
<?php include_once('pie_dentro.php'); ?>