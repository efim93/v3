<?php 
class enviaMail{				
	
private $remitente;	
private $destinatario;
private $contenidoMensaje;
private $titulo;

public function envioMailCliente($destinatario,$remitente, $contenidoMensaje, $titulo, $idCliente){

		// Para enviar un correo HTML, debe establecerse la cabecera Content-type	
		$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
		$cabeceras .= 'Content-type:text/html;charset=UTF-8' . "\r\n";
		$cabeceras .= 'From: '.$remitente.  "\r\n";	
			
		return mail($mDestinatario, '=?utf-8?B?'.base64_encode($titulo).'?=', $mensaje, $cabeceras);
																							
	}
	
	public function envioMailProductor($mRemitente, $contenidoMensaje, $titulo, $idCliente, $adjuntos){	//El remitente es el cliente							
		
		$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
		$cabeceras .= 'Content-type:text/html;charset=UTF-8' . "\r\n";
		$cabeceras .= 'From: '.$mRemitente. "\r\n";
		$cabeceras .= 'X-Confirm-Reading-To: '.$mRemitente. "\r\n";

		$constante = "const archivos = array(";
		
		foreach ($adjuntos as $archivo)
			{															
				$contenidoMensaje .= '<br><a href="http://imprimirbarato.es/serverService.php?orden=2&file='.$archivo->getRutaArchivo().'&name='.$archivo->getDocument()['name'].'" title="Descargar" target="_top">'.$archivo->getDocument()['name'].'</a>';
							
				$constante .= "'".$archivo->getRutaArchivo()."', ";
				
				if ($archivo->getRutaPortada()!=null)
				{																		
					$contenidoMensaje .= '<br><a href="http://imprimirbarato.es/serverService.php?orden=2&file='.$archivo->getRutaPortada().'&name='.$archivo->getPortada()['name'].'" title="Descargar" target="_top">'.$archivo->getPortada()['name'].'</a>';								
				
					$constante .= "'".$archivo->getRutaPortada()."', ";
				}		
																				
			}
		
		$constante = substr($constante, 0, strlen($constante)-2).");";

		$contenidoMensaje .= '<br><br><a href="http://imprimirbarato.es/serverService.php?orden=1&idPedido='.$idCliente.'.php" title="Borrar archivos del servidor y ordenar reparto" target="_top">Borrar archivos del servidor y ordenar el reparto</a>';								
		
		//Crea orden de reparto						
		$borrado = 'foreach(self::archivos as $ruta)
		{
			if (file_exists($ruta))
			{
				unlink($ruta);
				echo " borrado: ".basename($ruta).";"."\n";
			}
		}';
			
		$metas;
				  		
		foreach ($_SESSION["envio"] as $clave => $valor)
		{
			$metas .= '<meta name="'.$clave.'" content="'.$valor.'">'."\n";
		}
		
		$metas .= '<meta name="valor" content="'.number_format($_SESSION['precio'], 2).'€">'."\n";
		
		$reparto = file_get_contents("../plantillaReparto.php");
		$reparto = str_replace("//--->const archivos array", $constante, $reparto);	
		$reparto = str_replace("//--->borrado de archivos", $borrado, $reparto);
		$reparto = str_replace("<!--inserción de metas-->", $metas, $reparto);
		file_put_contents("../ordenes/".$idCliente.".php", $reparto);
		
		
		return mail(correoProduccion, '=?utf-8?B?'.base64_encode($titulo).'?=', $contenidoMensaje, $cabeceras);	//correoProduccion
	}
			

    /**
     * @return mixed
     */
    public function getRemitente(){
        return $this->remitente;
    }

    /**
     * @param mixed $remitente
     */
    public function setRemitente($remitente){
        $this->remitente = $remitente;
    }

    /**
     * @return mixed
     */
    public function getDestinatario(){
        return $this->destinatario;
    }

    /**
     * @param mixed $destinatario
     */
    public function setDestinatario($destinatario){
        $this->destinatario = $destinatario;
    }

    /**
     * @return mixed
     */
    public function getContenidoMensaje(){
        return $this->contenidoMensaje;
    }

    /**
     * @param mixed $contenidoMensaje
     *
     * @return self
     */
    public function setContenidoMensaje($contenidoMensaje){
        $this->contenidoMensaje = $contenidoMensaje;
    }

    /**
     * @return mixed
     */
    public function getTitulo(){
        return $this->titulo;
    }

    /**
     * @param mixed $titulo
     */
    public function setTitulo($titulo){
        $this->titulo = $titulo;
    }
}
 ?>