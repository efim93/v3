<?php

class Conectar{

	/* propriedades */ 
	private $server;
	private $db;
	private $charset;
	private $usuario;
	private $password;
	private $options;

	public function __construct($server='',$db='',$charset='',$user='',$password='',$options=''){
		$this->setServer($server);
		$this->setDb($db);
		$this->setCharset($charset);
		$this->setUsuario($user);
		$this->setPassword($password);
		$this->setOptions($options);
	}

    /**
     * @param mixed $server
     */
    public function setServer($server){
    	if($server==''){
    		$server="localhost";
    		}
    	$this->server = $server;
   	}
    

    /**
     * @param mixed $db
     */
    public function setDb($db){
    	if($db==''){
    		$db="";
    		}
    	$this->db = $db;
    }

    /**
     * @param mixed $charset
     */
    public function setCharset($charset){
        if($charset==''){
   				$charset="utf8";
    		}
        $this->charset = $charset;
    }

    /**
     * @param mixed $usuario
     */
    public function setUsuario($usuario){
        if($usuario==''){
			$usuario="root";
        	}
       	$this->usuario = $usuario;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password){
        if($password==''){
        	$password="";
        }
        $this->password = $password;
    }

    /**
     * @param mixed $options
     */
    public function setOptions($options){
        if($options==''){
        	$options=array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'UTF8'");
    		}	
    	$this->options = $options;
   	}

    /**
     * @return mixed
     */
    public function getServer(){
        return $this->server;
    }

    /**
     * @return mixed
     */
    public function getDb(){
        return $this->db;
    }

    /**
     * @return mixed
     */
    public function getCharset(){
        return $this->charset;
    }

    /**
     * @return mixed
     */
    public function getUsuario(){
        return $this->usuario;
    }

    /**
     * @return mixed
     */
    public function getPassword(){
        return $this->password;
    }

    /**
     * @return mixed
     */
    public function getOptions(){
        return $this->options;
    }

    public function conexion(){
        return new PDO("mysql:host={$this->getServer()};dbname={$this->getDb()};",$this->getUsuario(), $this->getPassword());   
    }

	public function __toString(){
		return 'server: '.$this->getServer().', dbname:'.$this->getDb().', user:'.$this->getUsuario().', password:'.$this->getPassword().', charset:'.$this->getCharset();
	}
}

?>