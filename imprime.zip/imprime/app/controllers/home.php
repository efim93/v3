<?php 

require_once('../app/models/AccionesBD.php');

 class home extends Controller{

	public function index(){
		$this->view('home/index');
	}

	public function formularioImprimir(){
		$this->view('home/formularioImprimir');
	}

	public function  avisoLegal(){
		$this->view('home/avisoLegal');
	}

	public function crearPedido(){
		$this->view('home/crearPedido');
	}

	public function verPedido(){
		$this->view('home/verPedido');
	}

	public function enviaCorreo(){
		$this->view('home/enviaCorreo');
	}
}

 ?>